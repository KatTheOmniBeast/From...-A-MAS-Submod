#A MAS Submod
#Recive a random message with binary code... who could it be from?

# READ ME:
# To play this submod, go to the 'Monika" catigory while talking. You'll see a "From Monika" choice.
# Download this submod by putting the context of the game folder into the game folder of MAS
# this is my first submod to comment if theres any bugs!
# I incuded a sprite cheat for MAS so anyone who wants to mod, can use those sprites withou having to spend
# hours looking for them
